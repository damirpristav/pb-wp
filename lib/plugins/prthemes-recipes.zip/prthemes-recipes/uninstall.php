<?php

// if uninstall.php is not called by WordPress, die
if ( !defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    die;
}

// delete recipe options
delete_post_meta_by_key( 'prt_recipe_title' );
delete_post_meta_by_key( 'prt_recipe_subtitle' );
delete_post_meta_by_key( 'prt_recipe_prep_time' );
delete_post_meta_by_key( 'prt_recipe_cook_time' );
delete_post_meta_by_key( 'prt_recipe_ingredients' );
delete_post_meta_by_key( 'prt_recipe_instructions' );
delete_post_meta_by_key( 'prt_recipe_image' );
delete_post_meta_by_key( 'prt_recipe_notes' );
delete_post_meta_by_key( 'prt_recipe_yields' );
delete_post_meta_by_key( 'prt_recipe_featured_image' );
