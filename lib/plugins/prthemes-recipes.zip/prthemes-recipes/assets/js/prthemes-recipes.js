/* ***********************************
 * PRThemes Recipe - main js file
 * **********************************/
(function($){

    $('.recipe-wrap .buttons .print-btn').on('click', function(e){
        e.preventDefault();
        $('.recipe-wrap').printThis();
    });

}(jQuery));
