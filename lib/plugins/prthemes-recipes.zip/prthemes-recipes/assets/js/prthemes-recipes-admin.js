/* ***********************************
 * PRThemes Recipe Admin - main js file
 * **********************************/
(function($){

    

}(jQuery));
