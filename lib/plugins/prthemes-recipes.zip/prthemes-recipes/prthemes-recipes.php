<?php
/*
Plugin Name:  PRThemes Recipes
Plugin URI:   http://prthemes.net/
Description:  PRThemes Recipes Plugin
Version:      1.0.0
Author:       PRThemes
Author URI:   http://prthemes.net/
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  prthemes-recipes
Domain Path:  /lang
*/

if ( ! defined( 'WPINC' ) ) {
    die;
}

if( !class_exists( 'PRThemes_Recipes' ) ){

    class PRThemes_Recipes{

        private $plugin_short_name = 'prt_recipes';

        public function __construct(){

            $this->enqueue_styles_and_scripts();
            $this->load_dependencies();

        }

        // enqueue css & js files
        public function enqueue_styles_and_scripts(){

            add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_styles' ) );
            add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
            add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue' ) );

        }

        // enqueue css
        public function enqueue_styles(){

            wp_register_style( $this->plugin_short_name . '_main', plugin_dir_url( __FILE__ ) . 'assets/css/prthemes-recipes.css' );
            wp_register_style( $this->plugin_short_name . '_print', plugin_dir_url( __FILE__ ) . 'assets/css/prthemes-recipes-print.css', '', false, 'print' );

            wp_enqueue_style( $this->plugin_short_name . '_main' );
            wp_enqueue_style( $this->plugin_short_name . '_print' );

        }

        // enqueue js
        public function enqueue_scripts(){

            wp_register_script( $this->plugin_short_name . '_printThis', plugin_dir_url( __FILE__ ) . 'assets/js/printThis.js', array('jquery'), '', true );
            wp_register_script( $this->plugin_short_name . '_main', plugin_dir_url( __FILE__ ) . 'assets/js/prthemes-recipes.js', array('jquery'), '', true );

            wp_enqueue_script( $this->plugin_short_name . '_printThis' );
            wp_enqueue_script( $this->plugin_short_name . '_main' );

        }

        // admin enqueue
        public function admin_enqueue(){

            global $pagenow;

            if( $pagenow === 'post.php' || $pagenow === 'post-new.php' ){

                wp_register_style( $this->plugin_short_name . '_recipes_admin', plugin_dir_url( __FILE__ ) . 'assets/css/prthemes-recipes-admin.css' );
                wp_enqueue_style( $this->plugin_short_name . '_recipes_admin' );
                wp_register_script( $this->plugin_short_name . '_recipes_admin', plugin_dir_url( __FILE__ ) . 'assets/js/prthemes-recipes-admin.js', array('jquery'), '', true );
                wp_enqueue_script( $this->plugin_short_name . '_recipes_admin' );

            }

        }

        // load dependencies
        public function load_dependencies(){

            require_once plugin_dir_path( __FILE__ ) . 'inc/recipes-custom-meta.class.php';
            require_once plugin_dir_path( __FILE__ ) . 'inc/recipes-shortcode.class.php';

        }

    }

    $prthemes_recipes = new PRThemes_Recipes;

}
