<?php

interface PRThemes_Recipes_Custom_Meta_Interface{

    public function add();
    public function display( $post );
    public function save( $post_id );

}

if( !class_exists( 'PRThemes_Recipes_Custom_Meta' ) ){

    class PRThemes_Recipes_Custom_Meta extends PRThemes_Recipes implements PRThemes_Recipes_Custom_Meta_Interface{

        private $prefix = 'prt_recipes_';

        public function __construct(){

            add_action( 'add_meta_boxes', array( $this, 'add' ) );
            add_action( 'save_post', array( $this, 'save' ) );
            add_action( 'admin_footer', array( $this, 'upload_image' ) );

        }

        public function add(){

            add_meta_box(
                $this->prefix . 'info_meta_box',
                __( 'Recipe Info', 'prthemes-recipes' ),
                array( $this, 'display' ),
                'post',
                'normal',
                'default',
                null
            );

        }

        public function display( $post ){

          wp_nonce_field( basename( __FILE__ ), $this->prefix . 'recipes_info_nonce' );

          ?>
          <div class="prt-recipes-notification">
              <p>
                <?php _e( 'To add recipe to this post just copy recipe shortcode', 'prthemes-recipes' ); ?>
                <span>[prthemes_recipe]</span>
                <?php _e( 'to above editor', 'prthemes-recipes' ); ?>.
              </p>
          </div>
          <div class="prt-recipes-wrap clearfix">
              <div class="prt-left-col">
                  <div class="prt-recipe-field-box">
                      <?php $recipe_title = get_post_meta( $post->ID, 'prt_recipe_title', true ); ?>
                      <h4><?php _e( 'Recipe Title', 'prthemes-recipes' ); ?> *</h4>
                      <p>
                          <input type="text" name="prt_recipe_title" value="<?php echo esc_attr( $recipe_title ); ?>" />
                      </p>
                      <p class="description"><?php _e( 'Enter your recipe name.', 'prthemes-recipes' ); ?></p>
                  </div>
                  <div class="prt-recipe-field-box">
                      <?php $recipe_subtitle = get_post_meta( $post->ID, 'prt_recipe_subtitle', true ); ?>
                      <h4><?php _e( 'Recipe Subtitle', 'prthemes-recipes' ); ?></h4>
                      <p>
                          <input type="text" name="prt_recipe_subtitle" value="<?php echo esc_attr( $recipe_subtitle ); ?>" />
                      </p>
                      <p class="description"><?php _e( 'Enter your recipe subtitle.', 'prthemes-recipes' ); ?></p>
                  </div>
                  <div class="prt-recipe-field-box">
                      <?php $recipe_prep_time = get_post_meta( $post->ID, 'prt_recipe_prep_time', true ); ?>
                      <h4><?php _e( 'Prep Time', 'prthemes-recipes' ); ?></h4>
                      <p>
                          <input type="number" min="0" step="1" name="prt_recipe_prep_time" value="<?php echo esc_attr( $recipe_prep_time ); ?>" class="small" />
                      </p>
                      <p class="description"><?php _e( 'Recipe preparation time, in minutes.', 'prthemes-recipes' ); ?></p>
                  </div>
                  <div class="prt-recipe-field-box">
                      <?php $recipe_cook_time = get_post_meta( $post->ID, 'prt_recipe_cook_time', true ); ?>
                      <h4><?php _e( 'Cook Time', 'prthemes-recipes' ); ?></h4>
                      <p>
                          <input type="number" min="0" step="1" name="prt_recipe_cook_time" value="<?php echo esc_attr( $recipe_cook_time ); ?>" class="small" />
                      </p>
                      <p class="description"><?php _e( 'Recipe cooking time, in minutes.', 'prthemes-recipes' ); ?></p>
                  </div>
                  <div class="prt-recipe-field-box">
                      <?php $recipe_ingredients = get_post_meta( $post->ID, 'prt_recipe_ingredients', true ); ?>
                      <h4><?php _e( 'Ingredients', 'prthemes-recipes' ); ?> *</h4>
                      <p>
                          <textarea name="prt_recipe_ingredients" class="bigger"><?php echo esc_html( $recipe_ingredients ); ?></textarea>
                      </p>
                      <p class="description"><?php _e( 'Enter your recipe ingredients. Each ingredient on a new line.', 'prthemes-recipes' ); ?></p>
                  </div>
                  <div class="prt-recipe-field-box">
                      <?php $recipe_instructions = get_post_meta( $post->ID, 'prt_recipe_instructions', true ); ?>
                      <h4><?php _e( 'Instructions', 'prthemes-recipes' ); ?> *</h4>
                      <p>
                          <textarea name="prt_recipe_instructions" class="bigger"><?php echo esc_html( $recipe_instructions ); ?></textarea>
                      </p>
                      <p class="description"><?php _e( 'Enter your recipe instructions. Each step on a new line( after you press enter ).', 'prthemes-recipes' ); ?></p>
                  </div>
              </div>
              <div class="prt-right-col">
                  <div class="prt-recipe-field-box">
                      <?php

                      $recipe_image = get_post_meta( $post->ID, 'prt_recipe_image', true );
                      $recipe_featured_image = get_post_meta( $post->ID, 'prt_recipe_featured_image', true );
                      $use_featured_image = ( isset( $recipe_featured_image ) &&  '1' === $recipe_featured_image ) ? 1 : 0;

                      ?>
                      <h4><?php _e( 'Recipe Image', 'prthemes-recipes' ); ?></h4>
                      <p>
                          <input type="hidden" name="prt_recipe_image" id="prt_recipe_image" value="<?php echo esc_url( $recipe_image ); ?>" />
                          <a href="#" class="button button-secondary prt-add-recipe-image"><?php _e( 'Add Image', 'prthemes-recipes' ); ?></a>
                          <a href="#" class="button button-secondary prt-remove-recipe-image"><?php _e( 'Remove Image', 'prthemes-recipes' ); ?></a>
                      </p>
                      <p>
                          <br>
                          <input type="checkbox" name="prt_recipe_featured_image" id="prt_recipe_featured_image" value="1" <?php checked( $use_featured_image, 1 ); ?> />
                          <label for="prt_recipe_featured_image"><?php _e( 'Use featured image', 'prthemes-recipes' ); ?></label>
                          <br><br>
                      </p>
                      <p class="description"><?php _e( 'Add your recipe image or use featured image.', 'prthemes-recipes' ); ?></p>
                      <div class="prt-recipe-preview-image">
                          <div class="image-preview-inner">
                          <?php if( $recipe_image ){ ?>
                              <img src="<?php echo esc_url( $recipe_image ); ?>" alt="" />
                          <?php } ?>
                          </div>
                      </div>
                  </div>
                  <div class="prt-recipe-field-box">
                      <?php $recipe_notes = get_post_meta( $post->ID, 'prt_recipe_notes', true ); ?>
                      <h4><?php _e( 'Notes', 'prthemes-recipes' ); ?></h4>
                      <p>
                          <textarea name="prt_recipe_notes"><?php echo esc_html( $recipe_notes ); ?></textarea>
                      </p>
                      <p class="description"><?php _e( 'Enter your additional notes here.', 'prthemes-recipes' ); ?></p>
                  </div>
                  <div class="prt-recipe-field-box">
                      <?php $recipe_yields = get_post_meta( $post->ID, 'prt_recipe_yields', true ); ?>
                      <h4><?php _e( 'Yields', 'prthemes-recipes' ); ?></h4>
                      <p>
                          <input type="number" step="1" min="1" name="prt_recipe_yields" value="<?php echo esc_attr( $recipe_yields ); ?>" class="small" />
                      </p>
                      <p class="description"><?php _e( 'Number of servings.', 'prthemes-recipes' ); ?></p>
                  </div>
              </div>
          </div>
          <div class="prt-recipes-notification">
              <p>
                <?php _e( '* fields are required. If you leave them empty recipe won\'t show on post.', 'prthemes-recipes' ); ?>
              </p>
          </div>
          <?php

        }

        public function save( $post_id ){

            if( !isset( $_POST[$this->prefix . 'recipes_info_nonce'] ) || !wp_verify_nonce( $_POST[$this->prefix . 'recipes_info_nonce'], basename( __FILE__ ) ) ){
                return;
            }

            if( !current_user_can( 'edit_post', $post_id ) ){
                return;
            }

            if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ){
                return;
            }

            if( isset( $_POST['prt_recipe_title'] ) ){
                update_post_meta( $post_id, 'prt_recipe_title', sanitize_text_field( $_POST['prt_recipe_title'] ) );
            }
            if( isset( $_POST['prt_recipe_subtitle'] ) ){
                update_post_meta( $post_id, 'prt_recipe_subtitle', sanitize_text_field( $_POST['prt_recipe_subtitle'] ) );
            }
            if( isset( $_POST['prt_recipe_prep_time'] ) ){
                update_post_meta( $post_id, 'prt_recipe_prep_time', sanitize_text_field( $_POST['prt_recipe_prep_time'] ) );
            }
            if( isset( $_POST['prt_recipe_cook_time'] ) ){
                update_post_meta( $post_id, 'prt_recipe_cook_time', sanitize_text_field( $_POST['prt_recipe_cook_time'] ) );
            }
            if( isset( $_POST['prt_recipe_ingredients'] ) ){
                update_post_meta( $post_id, 'prt_recipe_ingredients', sanitize_textarea_field( $_POST['prt_recipe_ingredients'] ) );
            }
            if( isset( $_POST['prt_recipe_instructions'] ) ){
                update_post_meta( $post_id, 'prt_recipe_instructions', sanitize_textarea_field( $_POST['prt_recipe_instructions'] ) );
            }
            if( isset( $_POST['prt_recipe_image'] ) ){
                update_post_meta( $post_id, 'prt_recipe_image', esc_url_raw( $_POST['prt_recipe_image'] ) );
            }

            $use_featured_image = ( isset( $_POST['prt_recipe_featured_image'] ) && '1' === $_POST['prt_recipe_featured_image'] ) ? 1 : 0;
            update_post_meta( $post_id, 'prt_recipe_featured_image', esc_attr( $use_featured_image ) );

            // $use_featured_image = $_POST['prt_recipe_featured_image'] ? true : false;
            // if( isset( $_POST['prt_recipe_featured_image'] ) ){
            //     update_post_meta( $post_id, 'prt_recipe_featured_image', $_POST['prt_recipe_featured_image'] );
            // }

            if( isset( $_POST['prt_recipe_notes'] ) ){
                update_post_meta( $post_id, 'prt_recipe_notes', sanitize_textarea_field( $_POST['prt_recipe_notes'] ) );
            }
            if( isset( $_POST['prt_recipe_yields'] ) ){
                update_post_meta( $post_id, 'prt_recipe_yields', sanitize_text_field( $_POST['prt_recipe_yields'] ) );
            }

        }

        public function upload_image(){

            ?>
            <script>
                jQuery(document).ready( function($) {

                    // Set all variables to be used in scope
                    var frame,
                        metaBox = $('#prt_recipes_info_meta_box'), // Your meta box id here
                        addImgLink = $('.prt-add-recipe-image'),
                        delImgLink = $( '.prt-remove-recipe-image'),
                        imgContainer = $( '.prt-recipe-preview-image .image-preview-inner'),
                        imgIdInput = $( '#prt_recipe_image' );

                    if( imgIdInput.val() == '' ){
                        imgContainer.hide();
                        delImgLink.addClass('hidden');
                    }else{
                        addImgLink.text( 'Change Image' );
                    }

                    // ADD IMAGE LINK
                    addImgLink.on( 'click',  function( event ){

                        event.preventDefault();

                        // If the media frame already exists, reopen it.
                        if ( frame ) {
                            frame.open();
                            return;
                        }

                        // Create a new media frame
                        frame = wp.media({
                            title: 'Select or Upload Media',
                            button: {
                              text: 'Use this media'
                            },
                            multiple: false  // Set to true to allow multiple files to be selected
                        });


                        // When an image is selected in the media frame...
                        frame.on( 'select', function() {

                            // Get media attachment details from the frame state
                            var attachment = frame.state().get('selection').first().toJSON();

                            // Send the attachment URL to our custom image input field.
                            imgContainer.html( '<img src="'+attachment.url+'" alt="" />' );
                            imgContainer.show();

                            // Send the attachment id to our hidden input
                            imgIdInput.val( attachment.url ).trigger('change');

                            // Change add image link text
                            addImgLink.text( 'Change Image' );

                            // Unhide the remove image link
                            delImgLink.removeClass( 'hidden' );
                        });

                        // Finally, open the modal on click
                        frame.open();
                    });

                    // DELETE IMAGE LINK
                    delImgLink.on( 'click',  function( event ){

                        event.preventDefault();

                        // Clear out the preview image
                        imgContainer.html( '' );
                        imgContainer.hide();

                        // Change Add Image button text
                        addImgLink.text( 'Add Image' );

                        // Hide the delete image link
                        delImgLink.addClass( 'hidden' );

                        // Delete the image id from the hidden input
                        imgIdInput.val( '' ).trigger('change');

                    });

                });
            </script>
            <?php

        }

    }
    $prthemes_recipes_custom_meta = new PRThemes_Recipes_Custom_Meta;

} // end if !class_exists
