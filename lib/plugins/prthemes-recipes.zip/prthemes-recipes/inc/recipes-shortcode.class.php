<?php

if( !class_exists( 'PRThemes_Recipes_Shortcode' ) ){

    class PRThemes_Recipes_Shortcode extends PRThemes_Recipes{

        public function __construct(){

            add_action( 'init', array( $this, 'shortcode_init' ) );

        }

        public function shortcode_init(){

            add_shortcode( 'prthemes_recipe', array( $this, 'recipe_shortcode' ) );

        }

        public function recipe_shortcode( $atts = [], $content = null ){

            global $post;

            $recipe_title = get_post_meta( $post->ID, 'prt_recipe_title', true );
            $recipe_subtitle = get_post_meta( $post->ID, 'prt_recipe_subtitle', true );
            $recipe_prep_time = get_post_meta( $post->ID, 'prt_recipe_prep_time', true );
            $recipe_cook_time = get_post_meta( $post->ID, 'prt_recipe_cook_time', true );
            $recipe_ingredients = get_post_meta( $post->ID, 'prt_recipe_ingredients', true );
            $recipe_instructions = get_post_meta( $post->ID, 'prt_recipe_instructions', true );
            $recipe_image = get_post_meta( $post->ID, 'prt_recipe_image', true );
            $recipe_notes = get_post_meta( $post->ID, 'prt_recipe_notes', true );
            $recipe_yields = get_post_meta( $post->ID, 'prt_recipe_yields', true );
            $use_featured_image = get_post_meta( $post->ID, 'prt_recipe_featured_image', true );

            $recipe_total_time = intval( $recipe_prep_time ) + intval( $recipe_cook_time );

            if( $recipe_prep_time > 60 ){
                $recipe_pt = $recipe_prep_time / 60;
                $recipe_pt_hours = floor( $recipe_pt );
                $recipe_pt_mins = ( $recipe_pt - $recipe_pt_hours ) * 60;
                $recipe_pt_output = $recipe_pt_hours . ' h ' . $recipe_pt_mins . ' min';
            }else{
                $recipe_pt_output = $recipe_prep_time . ' min';
            }

            if( $recipe_cook_time > 60 ){
                $recipe_ct = $recipe_cook_time / 60;
                $recipe_ct_hours = floor( $recipe_ct );
                $recipe_ct_mins = ( $recipe_ct - $recipe_ct_hours ) * 60;
                $recipe_ct_output = $recipe_ct_hours . ' h ' . $recipe_ct_mins . ' min';
            }else{
                $recipe_ct_output = $recipe_cook_time . ' min';
            }

            if( $recipe_total_time > 60 ){
                $recipe_tt = $recipe_total_time / 60;
                $recipe_hours = floor( $recipe_tt );
                $recipe_mins = ( $recipe_tt - $recipe_hours ) * 60;
                $recipe_tt_output = $recipe_hours . ' h ' . $recipe_mins . ' min';
            }else{
                $recipe_tt_output = $recipe_total_time . ' min';
            }

            $ingredients_arr = explode( "\n", str_replace( "\r", "", $recipe_ingredients ) );
            $ingredients_html = '<ul>';
            foreach( $ingredients_arr as $ingredient ){

                $ingredients_html .= '<li itemprop="recipeIngredient">' . $ingredient . '</li>';

            }
            $ingredients_html .= '</ul>';

            $instructions_arr = explode( "\n", str_replace( "\r", "", $recipe_instructions ) );
            $instructions_html = '';
            $i = 1;
            foreach( $instructions_arr as $instruction ){

                $instructions_html .= '<p itemprop="recipeInstructions"><span>' . $i . '</span>' . $instruction . '</p>';
                $i++;

            }

            $output = '<div class="recipe-wrap" itemscope itemtype="http://schema.org/Recipe">';

            if( !empty( $recipe_title ) ){
                $output .= '<h3 itemprop="name">' . $recipe_title . '</h3>';
            }

            if( !empty( $recipe_subtitle ) ){
                $output .= '<p class="recipe-subtitle">' . $recipe_subtitle . '</p>';
            }

            $output .= '<div class="buttons">';
            $output .= '<a href="#" class="print-btn">Print recipe</a>';
            $output .= '</div>';

            if( $recipe_total_time > 0 ){
                $output .= '<div class="recipe-time clearfix">';

                if( !empty( $recipe_prep_time ) ){
                    $output .= '<div class="col">';
                    $output .= '<p>' . __( 'Prep Time', 'prthemes-recipes' ) . '</p>';
                    $output .= '<p class="time" itemprop="prepTime">' . $recipe_pt_output . '</p>';
                    $output .= '</div>';
                }

                if( !empty( $recipe_cook_time ) ){
                    $output .= '<div class="col">';
                    $output .= '<p>' . __( 'Cook Time', 'prthemes-recipes' ) . '</p>';
                    $output .= '<p class="time" itemprop="cookTime">' . $recipe_ct_output . '</p>';
                    $output .= '</div>';
                }

                $output .= '<div class="col">';
                $output .= '<p>' . __( 'Total Time', 'prthemes-recipes' ) . '</p>';
                $output .= '<p class="time">' . $recipe_tt_output . '</p>';
                $output .= '</div>';
                $output .= '</div>';
            }

            if( !empty( $recipe_ingredients ) ){
                $output .= '<div class="ingredients clearfix">';
                $output .= '<div class="list-wrap">';
                $output .= '<h3>' . __( 'Ingredients', 'prthemes-recipes' ) . '</h3>';
                $output .= $ingredients_html;
                $output .= '</div>';

                if( isset( $use_featured_image ) && '1' === $use_featured_image && has_post_thumbnail( $post->ID ) ){
                    $output .= '<div class="image-wrap" itemprop="image" itemscope itemtype="http://schema.org/ImageObject">';
                    $output .= '<img src="' . wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), array( 200, 200 ) )[0] . '" alt="' . $recipe_title . '" itemprop="url">';
                    $output .= '</div>';
                }elseif( isset( $recipe_image ) && !empty( $recipe_image ) ){
                    $output .= '<div class="image-wrap" itemprop="image" itemscope itemtype="http://schema.org/ImageObject">';
                    $output .= '<img src="' . $recipe_image . '" alt="' . $recipe_title . '" itemprop="url">';
                    $output .= '</div>';
                }
                $output .= '</div>';
            }

            if( !empty( $recipe_instructions ) ){
                $output .= '<div class="instructions">';
                $output .= '<h3>' . __( 'Instructions', 'prthemes-recipes' ) . '</h3>';
                $output .= $instructions_html;
                $output .= '</div>';
            }

            if( !empty( $recipe_notes ) ){
                $output .= '<div class="notes">';
                $output .= '<h3>' . __( 'Notes', 'prthemes-recipes' ) . '</h3>';
                $output .= '<p>' . $recipe_notes . '</p>';
                $output .= '</div>';
            }

            if( !empty( $recipe_yields ) ){
              $output .= '<p class="yields" itemprop="recipeYield"><span>' . __( 'Yields', 'prthemes-recipes' ) . ':</span> ' . $recipe_yields . '</p>';
            }
            $output .= '</div>';

            if( !empty( $recipe_title ) && !empty( $recipe_ingredients ) && !empty( $recipe_instructions ) ){
                $content = $output;
            }else{
                $content = '';
            }



            return $content;

        }

    } // end class
    $prthemes_recipes_shortcode = new PRThemes_Recipes_Shortcode;

} // end if !class_exists
